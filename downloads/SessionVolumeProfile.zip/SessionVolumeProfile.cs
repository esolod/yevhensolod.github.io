#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private yevhensolod_studio.SessionVolumeProfile[] cacheSessionVolumeProfile;

		
		public yevhensolod_studio.SessionVolumeProfile SessionVolumeProfile(bool showValueArea, int valueAreaRangePct, bool showPeaks, int peakStrength)
		{
			return SessionVolumeProfile(Input, showValueArea, valueAreaRangePct, showPeaks, peakStrength);
		}


		
		public yevhensolod_studio.SessionVolumeProfile SessionVolumeProfile(ISeries<double> input, bool showValueArea, int valueAreaRangePct, bool showPeaks, int peakStrength)
		{
			if (cacheSessionVolumeProfile != null)
				for (int idx = 0; idx < cacheSessionVolumeProfile.Length; idx++)
					if (cacheSessionVolumeProfile[idx].ShowValueArea == showValueArea && cacheSessionVolumeProfile[idx].ValueAreaRangePct == valueAreaRangePct && cacheSessionVolumeProfile[idx].ShowPeaks == showPeaks && cacheSessionVolumeProfile[idx].PeakStrength == peakStrength && cacheSessionVolumeProfile[idx].EqualsInput(input))
						return cacheSessionVolumeProfile[idx];
			return CacheIndicator<yevhensolod_studio.SessionVolumeProfile>(new yevhensolod_studio.SessionVolumeProfile(){ ShowValueArea = showValueArea, ValueAreaRangePct = valueAreaRangePct, ShowPeaks = showPeaks, PeakStrength = peakStrength }, input, ref cacheSessionVolumeProfile);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.yevhensolod_studio.SessionVolumeProfile SessionVolumeProfile(bool showValueArea, int valueAreaRangePct, bool showPeaks, int peakStrength)
		{
			return indicator.SessionVolumeProfile(Input, showValueArea, valueAreaRangePct, showPeaks, peakStrength);
		}


		
		public Indicators.yevhensolod_studio.SessionVolumeProfile SessionVolumeProfile(ISeries<double> input , bool showValueArea, int valueAreaRangePct, bool showPeaks, int peakStrength)
		{
			return indicator.SessionVolumeProfile(input, showValueArea, valueAreaRangePct, showPeaks, peakStrength);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.yevhensolod_studio.SessionVolumeProfile SessionVolumeProfile(bool showValueArea, int valueAreaRangePct, bool showPeaks, int peakStrength)
		{
			return indicator.SessionVolumeProfile(Input, showValueArea, valueAreaRangePct, showPeaks, peakStrength);
		}


		
		public Indicators.yevhensolod_studio.SessionVolumeProfile SessionVolumeProfile(ISeries<double> input , bool showValueArea, int valueAreaRangePct, bool showPeaks, int peakStrength)
		{
			return indicator.SessionVolumeProfile(input, showValueArea, valueAreaRangePct, showPeaks, peakStrength);
		}

	}
}

#endregion
