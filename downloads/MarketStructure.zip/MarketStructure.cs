#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private yevhensolod_studio.MarketStructure[] cacheMarketStructure;

		
		public yevhensolod_studio.MarketStructure MarketStructure()
		{
			return MarketStructure(Input);
		}


		
		public yevhensolod_studio.MarketStructure MarketStructure(ISeries<double> input)
		{
			if (cacheMarketStructure != null)
				for (int idx = 0; idx < cacheMarketStructure.Length; idx++)
					if ( cacheMarketStructure[idx].EqualsInput(input))
						return cacheMarketStructure[idx];
			return CacheIndicator<yevhensolod_studio.MarketStructure>(new yevhensolod_studio.MarketStructure(), input, ref cacheMarketStructure);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.yevhensolod_studio.MarketStructure MarketStructure()
		{
			return indicator.MarketStructure(Input);
		}


		
		public Indicators.yevhensolod_studio.MarketStructure MarketStructure(ISeries<double> input )
		{
			return indicator.MarketStructure(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.yevhensolod_studio.MarketStructure MarketStructure()
		{
			return indicator.MarketStructure(Input);
		}


		
		public Indicators.yevhensolod_studio.MarketStructure MarketStructure(ISeries<double> input )
		{
			return indicator.MarketStructure(input);
		}

	}
}

#endregion
