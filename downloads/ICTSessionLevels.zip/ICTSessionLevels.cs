#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private yevhensolod_studio.ICTSessionLevels[] cacheICTSessionLevels;

		
		public yevhensolod_studio.ICTSessionLevels ICTSessionLevels(bool previousWeek, bool previousDay, bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes, bool breakByClose)
		{
			return ICTSessionLevels(Input, previousWeek, previousDay, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes, breakByClose);
		}


		
		public yevhensolod_studio.ICTSessionLevels ICTSessionLevels(ISeries<double> input, bool previousWeek, bool previousDay, bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes, bool breakByClose)
		{
			if (cacheICTSessionLevels != null)
				for (int idx = 0; idx < cacheICTSessionLevels.Length; idx++)
					if (cacheICTSessionLevels[idx].PreviousWeek == previousWeek && cacheICTSessionLevels[idx].PreviousDay == previousDay && cacheICTSessionLevels[idx].AsianSession == asianSession && cacheICTSessionLevels[idx].AsianSessionTimes == asianSessionTimes && cacheICTSessionLevels[idx].LondonSession == londonSession && cacheICTSessionLevels[idx].LondonSessionTimes == londonSessionTimes && cacheICTSessionLevels[idx].PreTradeSession == preTradeSession && cacheICTSessionLevels[idx].PreTradeSessionTimes == preTradeSessionTimes && cacheICTSessionLevels[idx].TradeSession == tradeSession && cacheICTSessionLevels[idx].TradeSessionTimes == tradeSessionTimes && cacheICTSessionLevels[idx].OpenRange == openRange && cacheICTSessionLevels[idx].OpenRangeMinutes == openRangeMinutes && cacheICTSessionLevels[idx].BreakByClose == breakByClose && cacheICTSessionLevels[idx].EqualsInput(input))
						return cacheICTSessionLevels[idx];
			return CacheIndicator<yevhensolod_studio.ICTSessionLevels>(new yevhensolod_studio.ICTSessionLevels(){ PreviousWeek = previousWeek, PreviousDay = previousDay, AsianSession = asianSession, AsianSessionTimes = asianSessionTimes, LondonSession = londonSession, LondonSessionTimes = londonSessionTimes, PreTradeSession = preTradeSession, PreTradeSessionTimes = preTradeSessionTimes, TradeSession = tradeSession, TradeSessionTimes = tradeSessionTimes, OpenRange = openRange, OpenRangeMinutes = openRangeMinutes, BreakByClose = breakByClose }, input, ref cacheICTSessionLevels);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.yevhensolod_studio.ICTSessionLevels ICTSessionLevels(bool previousWeek, bool previousDay, bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes, bool breakByClose)
		{
			return indicator.ICTSessionLevels(Input, previousWeek, previousDay, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes, breakByClose);
		}


		
		public Indicators.yevhensolod_studio.ICTSessionLevels ICTSessionLevels(ISeries<double> input , bool previousWeek, bool previousDay, bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes, bool breakByClose)
		{
			return indicator.ICTSessionLevels(input, previousWeek, previousDay, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes, breakByClose);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.yevhensolod_studio.ICTSessionLevels ICTSessionLevels(bool previousWeek, bool previousDay, bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes, bool breakByClose)
		{
			return indicator.ICTSessionLevels(Input, previousWeek, previousDay, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes, breakByClose);
		}


		
		public Indicators.yevhensolod_studio.ICTSessionLevels ICTSessionLevels(ISeries<double> input , bool previousWeek, bool previousDay, bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes, bool breakByClose)
		{
			return indicator.ICTSessionLevels(input, previousWeek, previousDay, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes, breakByClose);
		}

	}
}

#endregion
