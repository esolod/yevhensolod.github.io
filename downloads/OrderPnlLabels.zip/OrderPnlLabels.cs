#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private yevhensolod_studio.OrderPnlLabels[] cacheOrderPnlLabels;

		
		public yevhensolod_studio.OrderPnlLabels OrderPnlLabels()
		{
			return OrderPnlLabels(Input);
		}


		
		public yevhensolod_studio.OrderPnlLabels OrderPnlLabels(ISeries<double> input)
		{
			if (cacheOrderPnlLabels != null)
				for (int idx = 0; idx < cacheOrderPnlLabels.Length; idx++)
					if ( cacheOrderPnlLabels[idx].EqualsInput(input))
						return cacheOrderPnlLabels[idx];
			return CacheIndicator<yevhensolod_studio.OrderPnlLabels>(new yevhensolod_studio.OrderPnlLabels(), input, ref cacheOrderPnlLabels);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.yevhensolod_studio.OrderPnlLabels OrderPnlLabels()
		{
			return indicator.OrderPnlLabels(Input);
		}


		
		public Indicators.yevhensolod_studio.OrderPnlLabels OrderPnlLabels(ISeries<double> input )
		{
			return indicator.OrderPnlLabels(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.yevhensolod_studio.OrderPnlLabels OrderPnlLabels()
		{
			return indicator.OrderPnlLabels(Input);
		}


		
		public Indicators.yevhensolod_studio.OrderPnlLabels OrderPnlLabels(ISeries<double> input )
		{
			return indicator.OrderPnlLabels(input);
		}

	}
}

#endregion
