#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private yevhensolod_studio.KeyLevels[] cacheKeyLevels;

		
		public yevhensolod_studio.KeyLevels KeyLevels(double keyNumber)
		{
			return KeyLevels(Input, keyNumber);
		}


		
		public yevhensolod_studio.KeyLevels KeyLevels(ISeries<double> input, double keyNumber)
		{
			if (cacheKeyLevels != null)
				for (int idx = 0; idx < cacheKeyLevels.Length; idx++)
					if (cacheKeyLevels[idx].KeyNumber == keyNumber && cacheKeyLevels[idx].EqualsInput(input))
						return cacheKeyLevels[idx];
			return CacheIndicator<yevhensolod_studio.KeyLevels>(new yevhensolod_studio.KeyLevels(){ KeyNumber = keyNumber }, input, ref cacheKeyLevels);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.yevhensolod_studio.KeyLevels KeyLevels(double keyNumber)
		{
			return indicator.KeyLevels(Input, keyNumber);
		}


		
		public Indicators.yevhensolod_studio.KeyLevels KeyLevels(ISeries<double> input , double keyNumber)
		{
			return indicator.KeyLevels(input, keyNumber);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.yevhensolod_studio.KeyLevels KeyLevels(double keyNumber)
		{
			return indicator.KeyLevels(Input, keyNumber);
		}


		
		public Indicators.yevhensolod_studio.KeyLevels KeyLevels(ISeries<double> input , double keyNumber)
		{
			return indicator.KeyLevels(input, keyNumber);
		}

	}
}

#endregion
