#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private yevhensolod_studio.ICTSessionZones[] cacheICTSessionZones;

		
		public yevhensolod_studio.ICTSessionZones ICTSessionZones(bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes)
		{
			return ICTSessionZones(Input, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes);
		}


		
		public yevhensolod_studio.ICTSessionZones ICTSessionZones(ISeries<double> input, bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes)
		{
			if (cacheICTSessionZones != null)
				for (int idx = 0; idx < cacheICTSessionZones.Length; idx++)
					if (cacheICTSessionZones[idx].AsianSession == asianSession && cacheICTSessionZones[idx].AsianSessionTimes == asianSessionTimes && cacheICTSessionZones[idx].LondonSession == londonSession && cacheICTSessionZones[idx].LondonSessionTimes == londonSessionTimes && cacheICTSessionZones[idx].PreTradeSession == preTradeSession && cacheICTSessionZones[idx].PreTradeSessionTimes == preTradeSessionTimes && cacheICTSessionZones[idx].TradeSession == tradeSession && cacheICTSessionZones[idx].TradeSessionTimes == tradeSessionTimes && cacheICTSessionZones[idx].OpenRange == openRange && cacheICTSessionZones[idx].OpenRangeMinutes == openRangeMinutes && cacheICTSessionZones[idx].EqualsInput(input))
						return cacheICTSessionZones[idx];
			return CacheIndicator<yevhensolod_studio.ICTSessionZones>(new yevhensolod_studio.ICTSessionZones(){ AsianSession = asianSession, AsianSessionTimes = asianSessionTimes, LondonSession = londonSession, LondonSessionTimes = londonSessionTimes, PreTradeSession = preTradeSession, PreTradeSessionTimes = preTradeSessionTimes, TradeSession = tradeSession, TradeSessionTimes = tradeSessionTimes, OpenRange = openRange, OpenRangeMinutes = openRangeMinutes }, input, ref cacheICTSessionZones);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.yevhensolod_studio.ICTSessionZones ICTSessionZones(bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes)
		{
			return indicator.ICTSessionZones(Input, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes);
		}


		
		public Indicators.yevhensolod_studio.ICTSessionZones ICTSessionZones(ISeries<double> input , bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes)
		{
			return indicator.ICTSessionZones(input, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.yevhensolod_studio.ICTSessionZones ICTSessionZones(bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes)
		{
			return indicator.ICTSessionZones(Input, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes);
		}


		
		public Indicators.yevhensolod_studio.ICTSessionZones ICTSessionZones(ISeries<double> input , bool asianSession, string asianSessionTimes, bool londonSession, string londonSessionTimes, bool preTradeSession, string preTradeSessionTimes, bool tradeSession, string tradeSessionTimes, bool openRange, int openRangeMinutes)
		{
			return indicator.ICTSessionZones(input, asianSession, asianSessionTimes, londonSession, londonSessionTimes, preTradeSession, preTradeSessionTimes, tradeSession, tradeSessionTimes, openRange, openRangeMinutes);
		}

	}
}

#endregion
